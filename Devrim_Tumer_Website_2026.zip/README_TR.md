# Devrim Tümer — yenilenen akademik web sitesi

**Hazırlanma tarihi: 12 Kasım 2026**  
**Hedef adres: https://devrimtumer.com/**

**Yayımlanan özel önizleme:** https://devrim-tumer-mechanics.nifty-petal-7971.chatgpt.site

Önizleme, site sahibinin ChatGPT hesabıyla giriş gerektirir. Yayımlanması doğrulanmıştır. Bu önizleme mevcut devrimtumer.com alan adına yükleme yapıldığı anlamına gelmez.

Bu paket, fotoğraf kullanmadan tamamlanmış bir akademik site sunar. Kurulum gerektirmeyen HTML, CSS ve JavaScript dosyaları mevcut GitHub Pages düzenine uygundur. Ana odak; mekanik, malzeme modelleri ve bilimsel hesaplama arasındaki ilişkiyi açıkça anlatmak, yayınlara erişimi kolaylaştırmak ve akademik geçmişi doğru biçimde sunmaktır.

## 1. Paketi doğru yere yükleme

ZIP içindeki **`site/` klasörünün içeriği**, mevcut sitenin yayımlandığı dizine yerleştirilmelidir. ZIP dosyasının kendisini veya `site` klasörünü tek bir alt klasör olarak yüklemek yeterli değildir. Yayın dizininin en üst seviyesinde `index.html`, `CNAME`, diğer HTML dosyaları ve `assets/` bulunmalıdır.

`README_TR.md` ve `DEGERLENDIRME_TR.md` teslim belgeleridir; herkese açık site dizinine yüklenmeleri gerekli değildir. Paket başka ek teslim dosyaları içeriyorsa aynı ayrımı koruyun.

### Mevcut GitHub Pages deposuna uygulama

1. Mevcut depo ve site dosyalarının bir yedeğini saklayın. Gönderdiğiniz eski ZIP de bu amaçla kullanılabilir.
2. ZIP’i çıkarın ve `site/` klasörüne girin.
3. GitHub’da mevcut sitenin deposunu açın. **Add file → Upload files** üzerinden `site/` içindeki dosyaları ve `assets` klasörünü, mevcut yayın dizinine yükleyin. Aynı adlı dosyaların yeni sürümleriyle değiştiğini kontrol edin.
4. Değişiklikleri commit edin. Bir Git istemcisi kullanıyorsanız aynı dosya değişikliklerini mevcut yayın dalına commit/push edebilirsiniz.
5. **Settings → Pages** ekranında mevcut yayın kaynağını koruyun. Dal üzerinden yayın yapılıyorsa dosyalar seçili dalın `/(root)` veya `/docs` dizininde olmalıdır; paketin konumu bu ayarla aynı olmalıdır.
6. Özel alan adı alanında `devrimtumer.com` değerinin korunduğunu kontrol edin. Bu içerik yenilemesi için DNS kayıtlarını değiştirmek gerekmez.
7. GitHub Pages yayın işlemi tamamlandığında ana sayfayı, Research, Publications ve About & CV sayfalarını açın. CV indirmesini de kontrol edin. Eski görüntü kalıyorsa tarayıcıda tam yenileme yapın.

`CNAME` dosyası **devrimtumer.com** değerini korur. `.nojekyll` dosyası sade statik yayın için pakete dahildir; noktayla başlayan bu dosyayı atlamayın. GitHub Actions kullanan mevcut bir depoda yayın akışını değiştirmek yerine aynı statik dosyaları mevcut akışa dahil edin. GitHub, özel Actions yayınlarında alan adı ayarını depo ayarlarından yönetir; CNAME dosyası tek başına alan adı yapılandırmaz.

Resmî açıklamalar: [GitHub Pages yayın kaynağı](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site), [özel alan adı yönetimi](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site).

### Yayın durumunun anlamı

Dosyaların hazırlanması, mevcut GitHub deposuna gönderildikleri veya `devrimtumer.com` adresinin değiştiği anlamına gelmez. Bu çalışma sırasında mevcut GitHub deposuna yazma erişimi kullanılmamıştır. Yukarıdaki özel önizleme tasarımı incelemek içindir; mevcut alan adının yayın durumundan ayrıdır. Mevcut GitHub deposuna bu oturumda bağlı yazma erişimi bulunmadığı için alan adı üzerindeki yayın adımı kullanıcıya aittir.

## 2. Yerel önizleme

Çoğu içeriği `site/index.html` dosyasına çift tıklayarak görebilirsiniz. Daha tutarlı bir kontrol için bilgisayarınızda Python zaten kuruluysa `site` dizininde terminal açıp şu komutu çalıştırın:

```bash
python -m http.server 8000
```

Ardından [http://localhost:8000](http://localhost:8000) adresini açın. İşiniz bitince terminalde `Ctrl+C` ile sunucuyu durdurabilirsiniz. Siteyi kullanmak veya GitHub Pages’te yayımlamak için Python, Node.js, npm veya derleme adımı gerekmez.

## 3. Sayfalar ve dosyalar

| Dosya | İşlev |
| --- | --- |
| `index.html` | Ana sayfa, araştırma kimliği, seçili yayınlar ve iletişim |
| `research.html` | Araştırma temaları, çalışma yaklaşımı ve etkileşimli kinematik gösterim |
| `publications.html` | Dört seçili yayın, arama, konu filtresi, DOI ve BibTeX |
| `vitae.html` | Akademik geçmiş, görevler, öğretim, CV ve gizlilik açıklaması |
| `projects.html` | Eski Projects bağlantısını Research sayfasına yönlendirir |
| `news.html` | Eski News bağlantısını Publications sayfasına yönlendirir |
| `404.html` | Bulunamayan adresler için yönlendirici hata sayfası |
| `assets/css/site.css` | Renkler, yazı düzeni, mobil görünüm ve yazdırma kuralları |
| `assets/js/site.js` | Menü, yayın arama/filtreleme, atıf kopyalama ve yazdırma |
| `assets/js/mechanics.js` | Bilimsel SVG gösteriminin geometrisi ve kontrolleri |
| `assets/docs/Devrim_Tumer_CV.pdf` | Yenilenmiş iki sayfalık akademik CV |
| `assets/docs/publications.bib` | Dört yayının indirilebilir BibTeX kayıtları |
| `assets/images/` | Bilimsel çizim, site simgeleri ve paylaşım görseli |
| `assets/fonts/` | Yerel yazı tipi dosyaları ve lisansları |

Eski CV adresini korumak için kökteki `cv of Devrim Tümer.pdf`, güncel CV’nin bir uyumluluk kopyasıdır. İleride CV değiştirildiğinde iki PDF’yi birlikte güncelleyin.

## 4. Bakım için kısa rehber

- **Yayın eklemek:** `publications.html` içindeki yayın kartını, BibTeX bölümünü, arama verisini ve yapılandırılmış yayın listesini; ayrıca `publications.bib` dosyasını birlikte güncelleyin. İsterseniz ana sayfadaki seçili yayınları da yenileyin. Başlangıçtaki sonuç sayısını yeni toplamla eşitleyin.
- **Görev veya eğitim güncellemek:** `vitae.html`, ana sayfadaki kısa biyografi ve sayfalardaki Person yapılandırılmış verisini uyumlu tutun. CV’yi ayrıca yenileyin.
- **TU Graz görevi:** Kurumsal ziyaret kaydı Şubat–Aralık 2026 dönemini gösterir. Aralık 2026 sonrasında mevcut durumunuzu yeniden değerlendirip gerekli ifadeleri elle güncelleyin. Site otomatik görev değişikliği yapmaz.
- **İletişimi değiştirmek:** Ortak iletişim bölümü bütün ana sayfalarda ve 404 sayfasında bulunur. E-posta değişirse bu bölümleri, yapılandırılmış veriyi ve CV’yi birlikte düzenleyin.
- **Fotoğraf eklemek:** Şu an fotoğraf veya boş fotoğraf kutusu yoktur. Yeni fotoğraf hazır olduğunda yerleşimini ayrıca tasarlamak yeterlidir; mevcut sürüm fotoğraf bekleyen yarım bir düzen değildir.
- **Görünümü değiştirmek:** Renkler CSS dosyasının başındaki değişkenlerde tanımlıdır. Araştırma çizimi, gerçek veri grafiği yerine kullanılan bir fotoğraf değildir; anlamını koruyarak düzenlenmelidir.

Her içerik güncellemesinden sonra ilgili bağlantıları açın, dar ekranı kontrol edin ve sitemap tarihini yalnızca gerçekten güncellenen sayfalarda değiştirin. Ziyaretçi, yayın ve CV bilgilerinin doğruluğu görsel yenilik kadar değerlidir.
