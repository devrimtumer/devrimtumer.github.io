# Akademik site yenilemesi — değerlendirme ve kararlar

**Devrim Tümer · 12 Kasım 2026**

## Tasarımın temel kararı

Yeni site, Devrim Tümer’in teorik mekanik ve bilimsel hesaplama çalışmalarını açık, sakin ve güçlü bir akademik anlatı içinde sunmak üzere düzenlendi. Bilimsel yetkinlik; somut araştırma soruları, doğrulanabilir yayınlar, doğru unvanlar ve dikkatli bir görsel düzen üzerinden görünür kılındı.

İstenen bilimsel derinlik, ciddiyet ve ayırt edici kimlik; ölçülü tipografi, matematiksel düşünceyi gösteren içerik, özgün bilimsel çizimler ve dikkatli teknik uygulama ile karşılandı. Akademik tanıtım, mevcut araştırma alanlarına ve doğrulanmış yayınlara dayanır.

## Eski pakette bulunan sorunlar

Gönderilen kaynak dosyalarda yalnızca görsel eskime bulunmuyordu. CV sayfasının tarayıcı başlığı başka bir kişiye aitti; Projects ve News dosyaları boştu. JavaScript ve stil yolları gerçek dosya konumlarıyla uyuşmuyordu. Eksik menü, footer, harita ve favicon dosyaları isteniyordu. CV yazdırma bağlantısı gerçek bir işlem yapmıyordu.

Ana HTML dosyası 455.063 bayttı; bunun 448.206 baytı, büyük ölçüde dışarı aktarılmış Font Awesome tanımları olan satır içi stillerden oluşuyordu. Fotoğraf ise haricî bir görüntü sunucusundan yükleniyordu. Yeni yapı bu kalıntıları temizledi ve görevleri anlaşılır dosyalara ayırdı. Yeni ana HTML 14.988 bayttır; HTML dosyasındaki azalma yaklaşık %96,7’dir. Bu oran yalnızca HTML boyutunu karşılaştırır; toplam site aktarımına veya hız puanına eşit değildir. Ana sayfanın yanına gerçek araştırma, yayın ve akademik geçmiş sayfaları eklendi.

## Görsel ve içerik yaklaşımı

Sıcak kâğıt tonları, koyu mürekkep rengi ve sınırlı kiremit vurgusu, bilimsel yayın estetiğine yakın bir dil oluşturur. Serif başlıklar kavramsal derinliği, sade sans-serif metinler okunabilirliği destekler. Boşluklar ve ince çizgiler içerik hiyerarşisini kurar; her bölüm aynı kart şablonunu tekrar etmez.

Ana sayfa araştırmacının adını ve alanını ilk ekranda açıklar. Ardından araştırma temaları, çalışma yaklaşımı, seçili yayınlar, akademik geçmiş ve iletişim gelir. Bu sıra, ziyaretçinin “Ne çalışıyor?”, “Nasıl çalışıyor?”, “Ne yayımladı?” ve “Nasıl ulaşırım?” sorularını cevaplar.

İçerik İngilizcedir; uluslararası akademik kullanım hedeflenmiştir. Türkçe yayın adı bibliyografik kayıtta korunmuş, yayıncı tarafından verilen İngilizce başlık görünür sunumda kullanılmıştır. Fotoğraf, siluet veya sonradan doldurulacak boş kutu bulunmaz. Görsel kimlik baştan itibaren fotoğrafsız tamamlanmıştır.

## Akademik doğruluk ve CV

Dört seçili hakemli yayın; başlık, yıl, dergi, DOI ve yazar sırası bakımından kaynaklarla karşılaştırıldı. Eski CV’deki 2020 makalesinin son iki yazarının sırası düzeltildi. Termal depolama makalesinde M. Evren Toygar’ın baş harfleri yayıncı kaydına uygun hâle getirildi. 2026 tarihli iki eksenli test cihazı çalışması eklendi.

Yenilenen iki sayfalık CV, web sitesiyle tutarlı eğitim, görev, araştırma, öğretim ve yayın bilgileri içerir. Doktora devam ettiği için “Ph.D. Candidate” kullanılır. TU Graz ziyaretleri kurumsal kayıttaki dönemleriyle belirtilir. Araştırma sayfası devam eden çalışma alanlarını anlatır; bunları yayımlanmış ve doğrulanmış yeni bir kurucu yasa olarak sunmaz. Özel proje adları, yayımlanmamış formülasyon ayrıntıları ve kişisel yazışma bilgileri kullanılmaz.

Başlıca bibliyografik ve kurumsal kaynaklar:

- [2026: iki eksenli test cihazı — yayıncı kaydı](https://dergipark.org.tr/en/pub/deumffmd/article/1633531)
- [2024: infraspinatus yırtıkları — DOI](https://doi.org/10.1016/j.jmbbm.2024.106600) ve [PubMed kaydı](https://pubmed.ncbi.nlm.nih.gov/38870586/)
- [2024: bazalt camı ve termal depolama — Springer](https://link.springer.com/article/10.1007/s10973-023-12815-9)
- [2020: implant malzemelerinin kaplanması — yayıncı](https://www.sciencedirect.com/science/article/pii/S2238785420320196)
- [TU Graz ziyaretçi kaydı](https://biomech.tugraz.at/visitors)
- [Ege Üniversitesi Mekanik Anabilim Dalı](https://me.ege.edu.tr/tr-3862/mekanik_anabilim_dali.html)

## Bilimsel gösterimin kapsamı

Research sayfasındaki SVG, bir malzeme elemanının hacim koruyan homojen deformasyonunu gösterir. Kullanıcı eksenel uzamayı veya basit kaymayı değiştirir; deformasyon gradyanı ve hacim oranı birlikte görüntülenir.

Eksenel durumda $F=\operatorname{diag}(\lambda^{-1/2},\lambda,\lambda^{-1/2})$; basit kaymada $F_{12}=\gamma$, köşegen bileşenler birdir. Her iki dönüşüm için $J=\det F=1$ olur. Lifler de aynı dönüşümden geçirilir. Matris değerleri görüntüleme için yuvarlanır.

Bu araç bir **kinematik açıklamadır**. Gerilme hesaplamaz; sonlu eleman çözümü, deney sonucu veya NCM doğrulaması üretmez. Sayfa bu sınırı açıkça belirtir. Animasyon kullanıcı isteğiyle başlar, durdurulabilir ve azaltılmış hareket tercihini dikkate alır.

## Teknik kalite ve doğrulama

Site derleme gerektirmez. Yazı tipleri yereldir; analitik, reklam izleyicisi veya çalışmayan iletişim formu eklenmemiştir. Menü, filtre ve gösterim değerleri tarayıcıda işlenir. JavaScript kapalıyken akademik içerik, bağlantılar ve statik çizim erişilebilir kalır.

Başlıklar, açıklamalar, canonical bağlantıları, sosyal paylaşım görseli, Person/WebPage/yayın yapılandırılmış verisi, sitemap, robots dosyası ve özel 404 sayfası hazırlanmıştır. Bunlar doğru tanıtım ve taranabilirlik sağlar; arama sıralaması garantisi anlamına gelmez.

Yürütülen kontroller; yerel bağlantı ve dosya bütünlüğü, JavaScript sözdizimi, JSON/XML geçerliliği, masaüstü görünüm, 390 ve 768 piksel genişliklerde düzen ve menü davranışı, yayın filtreleri, boş sonuç ve sıfırlama, BibTeX kopyalama ve gösterim kontrollerini kapsar. İki yayınlık konu filtresi, tek bazalt yayını araması, kayma 0,35 ve uzama 0,80 durumları kontrol edilmiştir. 320 piksel genişlikte ana sayfa, yayınlar ve araştırma görünümü de tarayıcı içinde kontrol edildi. Saptanan taşmalar düzeltildikten sonra yatay taşma kalmadığı doğrulandı. JavaScript kapalı araştırma görünümünde içerik ve statik çizim kontrol edildi. Bu kontroller, tarayıcı içindeki farklı genişlikte iframe görünüm alanlarıyla gerçekleştirildi.

Ana metin renk çiftlerinde hesaplanan kontrast en az 4,60:1’dir. Bu bulgu bütün site için eksiksiz WCAG sertifikası değildir. Fiziksel telefonlarda geniş cihaz testi ve bağımsız Lighthouse ölçümü yapılmış sayılmaz; bu nedenle puan veya uyumluluk sertifikası iddia edilmez. 112 yerel dosya/bağlantı kontrolü hatasız tamamlandı. Özel önizleme başarıyla yayımlandı; mevcut devrimtumer.com alan adına yükleme yapılmadı. Önizleme için site sahibinin ChatGPT hesabıyla giriş gerekir.

GitHub Pages’e yükleme adımları diğer teslim belgesindedir. Kaynak paketinin tamamlanması ile mevcut alan adının yayına alınması ayrı durumlardır; bu çalışma mevcut GitHub hesabında değişiklik yapıldığı anlamına gelmez.
